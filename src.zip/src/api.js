export const baseUrl = "https://ecommerce-backend-8hzj.onrender.com";
console.log("BASE URL ===>", baseUrl);




// const baseUrl = "https://ecommerce-backend-8hzj.onrender.com"