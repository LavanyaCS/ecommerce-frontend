import React from 'react'
import Carousel from '../pages/Home/Carousel'

function Dashboard() {
  return (
    <div>
      
    <Carousel />
      Dashbpard
    </div>
  )
}

export default Dashboard
